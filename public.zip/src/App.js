import logo from "./logo.svg";
import "./App.css";
import Product_list from "./components/product_list";

function App() {
  return (
    <div className="App">
      <div>
        <Product_list />
      </div>
    </div>
  );
}

export default App;
