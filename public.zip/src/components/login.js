import React, { useState } from 'react'

function login() {

  const [email , setEmail] = useState("hiii@gmail.com")
  const [password , setPassword] = useState("Hiii@123")

  return (
    <div>
      <input
        type="email"
        placeholder="Enter Your Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />
      <input
        type="password"
        placeholder="Enter Your password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
    </div>
  );
}

export default login