import axios from "axios";
import "../App.css";
import React, { useEffect, useState } from "react";

function Product_list() {
  const [allData, setAllData] = useState([]);
  console.log("alldata", allData);

  useEffect(() => {
    axios
      .get("https://fakestoreapi.com/products")
      .then((res) =>
        // console.log(res.data),
        setAllData(res.data)
      )
      .catch((error) => console.log(error));
  }, []);

  return (
    <div style={{display:'flex',justifyContent:'center',flexWrap:'wrap',alignContent:'center',margin:'auto',marginTop:'50px'}}>
      {allData.map((elem) => {
        return (
          <>
            <div
              style={{
                width: "33.33%",
                display: "flex",
                flexDirection: "column",
                marginTop: "30px",
              }}
            >
              <div
                style={{
                  height: "100%",
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <img src={elem.image} className="imageStyle" />
                <h3 style={{ height: "50px",width:'200px' }}>
                  {elem.title.slice(0,30)}{elem.title.length>30?"...":null}
                </h3>
                <button style={{}}> Add to Cart</button>
              </div>
            </div>
          </>
        );
      })}
    </div>
  );
}

export default Product_list;
